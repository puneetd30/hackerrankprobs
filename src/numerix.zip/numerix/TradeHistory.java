package numerix;

public class TradeHistory {

	private double oldAverage;
	private int tradePositionCompare;

	public double getOldAverage() {
		return oldAverage;
	}

	public void setOldAverage(double oldAverage) {
		this.oldAverage = oldAverage;
	}

	public int getTradePositionCompare() {
		return tradePositionCompare;
	}

	public void setTradePositionCompare(int tradePositionCompare) {
		this.tradePositionCompare = tradePositionCompare;
	}
}
