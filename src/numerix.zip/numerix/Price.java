package numerix;

public class Price {

	String productName;
	double numericalPrice;

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public double getNumericalPrice() {
		return numericalPrice;
	}

	public void setNumericalPrice(double numericalPrice) {
		this.numericalPrice = numericalPrice;
	}

}
